package s373.flob;

public abstract class baseBlob {
	public int id;
	public int pixelcount;
	public int boxminx, boxminy, boxmaxx, boxmaxy;
	public int boxcenterx, boxcentery;

}
